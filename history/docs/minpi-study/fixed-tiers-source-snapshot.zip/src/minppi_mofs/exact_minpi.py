"""Exact size-stratified pivotal votes on supervised hit/miss triplets."""

from math import ceil

import numpy as np
import pandas as pd
from scipy.special import gammaln
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils.validation import check_is_fitted

from minppi_mofs.piv2 import _folds
from minppi_mofs.piv3_compact_filter import _reference_geometry, _scaled, _triplets


def witness_margins(X, y, task, seed):
    """Return reference-fold standardized miss-minus-hit distances for training queries."""
    if task not in {'classification', 'regression'}:
        raise ValueError('task must be classification or regression')
    X, y = np.asarray(X), np.asarray(y)
    if X.ndim != 2 or X.shape[1] == 0 or y.shape != (len(X),) or pd.isna(y).any():
        raise ValueError('Expected a nonempty matrix and complete aligned one-dimensional targets')
    if task == 'regression' and not np.isfinite(y.astype(float)).all():
        raise ValueError('Regression targets must be finite')
    folds = _folds(y, task, np.random.default_rng(seed), row_limit=256)
    if folds is None or min(map(len, folds)) < 2:
        raise ValueError('Insufficient training observations for hit/miss witnesses')
    ref, query = folds
    ref_y, query_y = y[ref], y[query]
    if task == 'regression':
        cuts = np.unique(np.quantile(ref_y, [.2, .4, .6, .8]))
        ref_y, query_y = (np.searchsorted(cuts, part) for part in (ref_y, query_y))
    raw = np.asarray(X[ref], dtype=np.float32)
    valid = np.isfinite(raw)
    observed = np.maximum(valid.sum(axis=0), 1)
    center = np.where(valid, raw, 0.).sum(axis=0) / observed
    residual = np.where(valid, raw - center, 0.)
    scale = np.sqrt((residual * residual).sum(axis=0) / observed)
    scale = np.where(scale > 1e-7, scale, 1.).astype(np.float32)
    ref_x = _scaled(raw, center, scale)
    query_x = _scaled(X[query], center, scale)
    weights = _reference_geometry(ref_x, ref_y)
    margins = _triplets(ref_x, query_x, ref_y, query_y, weights)
    if margins is None:
        raise ValueError('A witness lacks a reference hit or miss')
    return margins


def _log_choose_table(width, k):
    # A triangular recurrence avoids cancellation between large log-factorials.
    table = np.full((width + 1, k + 1), -np.inf)
    table[:, 0] = 0.
    for r in range(1, k + 1):
        counts = np.arange(r, width + 1)
        table[counts, r] = table[counts, r-1] + np.log((counts-r+1) / r)
    return table


def _margin_mass(plus, minus, zero, k, margin, log_choose, normalizer):
    """Three-color hypergeometric probability that sum equals margin."""
    mass = np.zeros(len(plus))
    for pairs in range((k - abs(margin)) // 2 + 1):
        pos = pairs + max(0, margin)
        neg = pairs + max(0, -margin)
        abstain = k - pos - neg
        log_mass = log_choose[plus, pos] + log_choose[minus, neg] + log_choose[zero, abstain]
        mass += np.exp(log_mass - normalizer)
    return mass


def pivotal_rates(votes, tiers):
    """Mean signed marginal utility at each finite-population coalition size."""
    votes = np.asarray(votes)
    if votes.ndim != 2 or min(votes.shape) == 0 or not np.isin(votes, [-1, 0, 1]).all():
        raise ValueError('Expected a nonempty ternary vote matrix')
    n, p = votes.shape
    tiers = tuple(tiers)
    if not tiers or any(not isinstance(k, (int, np.integer)) or not 0 <= k < p for k in tiers):
        raise ValueError('Coalition sizes must be integers in [0,p)')
    positive = votes > 0
    negative = votes < 0
    plus, minus = positive.sum(axis=1), negative.sum(axis=1)
    zero = p - plus - minus
    log_choose = _log_choose_table(p, max(tiers))
    weights = np.zeros((2, len(tiers), n))
    for t, k in enumerate(tiers):
        norm = log_choose[p-1, k]
        for index, diff in ((0, -1), (1, 1)):
            # Rows lacking the candidate sign have no such feature to receive a weight.
            a = np.maximum(0, plus - int(index == 0))
            b = np.maximum(0, minus - int(index == 1))
            weight = _margin_mass(a, b, zero, k, 0, log_choose, norm)
            weight += _margin_mass(a, b, zero, k, diff, log_choose, norm)
            weights[index, t] = weight
    return (weights[0] @ positive - weights[1] @ negative) / n


class ExactMinPI(TransformerMixin, BaseEstimator):
    """Fixed-budget dense numeric feature screen based on worst-tier pivotality."""

    def __init__(self, *, task='classification', random_state=42, fraction=.1):
        self.task = task
        self.random_state = random_state
        self.fraction = fraction

    def fit(self, X, y):
        if not 0 < self.fraction <= 1:
            raise ValueError('fraction must be in (0, 1]')
        if isinstance(X, pd.DataFrame) and not X.columns.is_unique:
            raise ValueError('Feature names must be unique')
        margins = witness_margins(X, y, self.task, self.random_state)
        votes = np.sign(margins).astype(np.int8)
        self.n_witnesses_, self.n_features_in_ = votes.shape
        self.feature_names_in_ = np.asarray(X.columns) if isinstance(X, pd.DataFrame) else None
        p = self.n_features_in_
        self.tier_sizes_ = np.unique(np.minimum([0, 4, 16], p-1))
        self.tier_rates_ = pivotal_rates(votes, self.tier_sizes_)
        self.scores_ = self.tier_rates_.min(axis=0)
        self.ranking_ = np.argsort(-self.scores_, kind='stable')
        self.support_ = np.zeros(p, dtype=bool)
        self.support_[self.ranking_[:ceil(self.fraction*p)]] = True
        return self

    def transform(self, X):
        check_is_fitted(self, 'support_')
        if np.ndim(X) != 2 or np.shape(X)[1] != self.n_features_in_:
            raise ValueError('Feature count differs from fit')
        if isinstance(X, pd.DataFrame):
            if self.feature_names_in_ is not None and not np.array_equal(X.columns, self.feature_names_in_):
                raise ValueError('Feature schema differs from fit')
            return X.iloc[:, self.support_]
        return np.asarray(X)[:, self.support_]

    def get_support(self, indices=False):
        check_is_fitted(self, 'support_')
        return np.flatnonzero(self.support_) if indices else self.support_.copy()

