"""Scikit-learn transformer for the support-only pivotal ranking."""
from math import ceil

import numpy as np
from sklearn.base import BaseEstimator
from sklearn.feature_selection import SelectorMixin
from sklearn.utils.validation import check_is_fitted, validate_data

from minppi_mofs.certified_minpi import top_from_votes
from minppi_mofs.exact_minpi import witness_margins
from minppi_mofs.integer_minpi import rational_top_from_votes


class PivotalSupportSelector(SelectorMixin, BaseEstimator):
    """Fit training witnesses and retain a stable prefix in the input feature order.

    With arithmetic="float" selection uses the existing double-precision
    certificate. Use arithmetic="rational" to resolve the true finite-game order.
    """

    def __init__(self, *, fraction=.1, task="classification", random_state=42, arithmetic="float"):
        self.fraction = fraction
        self.task = task
        self.random_state = random_state
        self.arithmetic = arithmetic

    def __sklearn_tags__(self):
        tags = super().__sklearn_tags__()
        tags.input_tags.allow_nan = True
        return tags

    def fit(self, X, y):
        if not 0 < self.fraction <= 1:
            raise ValueError("fraction must be in (0,1]")
        if self.arithmetic not in ("float", "rational"):
            raise ValueError("arithmetic must be 'float' or 'rational'")
        if hasattr(X, "columns") and not X.columns.is_unique:
            raise ValueError("Feature names must be unique")
        X = validate_data(self, X, dtype=None, ensure_all_finite="allow-nan")
        votes = np.sign(witness_margins(X, y, self.task, self.random_state)).astype(np.int8)
        count = ceil(self.fraction*self.n_features_in_)
        scorer = rational_top_from_votes if self.arithmetic == "rational" else top_from_votes
        support, self.diagnostics_ = scorer(votes, count)
        self.support_ = np.zeros(self.n_features_in_, dtype=bool)
        self.support_[support] = True
        return self

    def _get_support_mask(self):
        check_is_fitted(self, "support_")
        return self.support_
